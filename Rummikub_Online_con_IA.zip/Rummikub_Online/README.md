# Rummikub Online

Juego multijugador online inspirado en las reglas estándar de Rummikub. Soporta salas privadas para 2 a 4 personas y funciona en celular y computador.

## Requisitos
- Node.js 18 o superior.
- Conexión a internet para el modo multijugador.

## Ejecutar en tu computador
1. Descomprime el ZIP.
2. Abre una terminal dentro de la carpeta `Rummikub_Online`.
3. Ejecuta `npm install`.
4. Ejecuta `npm start`.
5. Abre `http://localhost:3000` en el navegador.

Para jugar con otras personas a través de internet, debes desplegar la carpeta en un servicio que mantenga Node.js y WebSockets activos (por ejemplo, Render). No basta con abrir `index.html` como archivo local: el servidor es el que crea las salas, reparte las fichas y valida las jugadas.

## Despliegue en Render
- Crea un servicio tipo **Web Service** conectado a tu repositorio.
- Runtime: Node.
- Build Command: `npm install`
- Start Command: `npm start`
- No necesitas configurar una ruta de comprobación; está disponible `GET /api/ping`.
- Usa una instancia que admita conexiones WebSocket y mantenga el proceso Node activo.

## Qué incluye
- Salas privadas de 5 caracteres, de 2 a 4 jugadores.
- 106 fichas: dos juegos del 1 al 13 en cuatro colores y dos comodines.
- 14 fichas iniciales por jugador.
- Apertura obligatoria de 30 puntos.
- Escaleras y grupos.
- Robar una ficha y pasar el turno.
- Reorganización de la mesa por selección de fichas, creación de grupos y adición a grupos existentes.
- Comprobación de que todas las combinaciones finales sean válidas.
- Validación en servidor: el navegador no decide por sí solo si una jugada es legal.
- Comodines: representación asignada y recuperación mediante la ficha que sustituyen.
- Puntuación de ronda y penalización de 30 puntos por comodín restante.
- Recuperación de sesión en caso de reconexión del navegador durante la partida.

## Controles
- Toca o haz clic en una ficha para seleccionarla.
- Selecciona fichas del atril o de la mesa.
- **Crear grupo** mueve la selección a una nueva combinación.
- Para añadir fichas a una combinación, toca su etiqueta `GRUPO` y pulsa **Añadir al grupo**.
- **Devolver al atril** permite devolver fichas propias que habías bajado durante ese turno.
- **Deshacer** restaura el estado al comienzo del turno.
- **Validar y terminar turno** envía la jugada al servidor.

## Notas sobre reglas
Esta implementación cubre las reglas estándar solicitadas: apertura de 30, combinaciones, manipulación de la mesa, robo, comodines y puntuación de ronda. Algunas ediciones o reglas de casa difieren en detalles del uso del comodín y el cierre por montón agotado; esta versión exige colocar la ficha exacta que sustituye al comodín y reutilizarlo en otra combinación durante el mismo turno. Cuando se agota el montón, la ronda continúa mientras alguien pueda jugar y termina después de una vuelta completa de pases consecutivos.

Las partidas se guardan en memoria del proceso. Reiniciar o suspender el servidor elimina las salas y partidas activas.


## Jugar en solitario contra IA

En la pantalla inicial elige jugar contra 1, 2 o 3 rivales controlados por la computadora y pulsa **Jugar solo**. Después pulsa **Comenzar partida** en la sala. Las IA juegan automáticamente, forman grupos y escaleras legales desde su atril, intentan añadir fichas a combinaciones existentes cuando ya abrieron y roban cuando no encuentran una jugada válida.

La IA se ejecuta en el servidor para que el turno y las fichas se mantengan sincronizados. Esta primera versión usa una estrategia sencilla; no realiza todavía búsquedas profundas de todas las reorganizaciones posibles de la mesa.
