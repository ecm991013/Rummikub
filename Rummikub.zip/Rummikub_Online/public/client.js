(() => {
  const socket = io({
    reconnection: true, reconnectionAttempts: Infinity,
    reconnectionDelay: 700, reconnectionDelayMax: 5000,
    timeout: 15000, transports: ['websocket', 'polling']
  });
  const $ = id => document.getElementById(id);
  const screens = ['homeScreen', 'lobbyScreen', 'gameScreen'];
  let roomCode = null;
  let myId = null;
  let token = null;
  let state = null;
  let draftGroups = [];
  let draftHand = [];
  let selected = new Set();
  let targetGroup = null;
  let originalHandIds = new Set();
  let originalTableIds = new Set();
  let toastTimer = null;
  let lastNotice = '';
  let rackDrag = null;
  const avatarOptions = ['person1','person2','person3','person4','person5','person6','person7','person8'];
  const tileThemes = ['classic','modern','marble','wood','neon','royal','pastel'];
  let selectedAvatar = localStorage.getItem('rummikubAvatar') || 'person1';
  let selectedTheme = localStorage.getItem('rummikubTileTheme') || 'classic';

  function applyCustomization() {
    if (!tileThemes.includes(selectedTheme)) selectedTheme = 'classic';
    if (!avatarOptions.includes(selectedAvatar)) selectedAvatar = 'person1';
    document.body.dataset.tileTheme = selectedTheme;
    document.querySelectorAll('[data-theme]').forEach(button => {
      button.classList.toggle('active', button.dataset.theme === selectedTheme);
      button.setAttribute('aria-pressed', String(button.dataset.theme === selectedTheme));
    });
    document.querySelectorAll('[data-avatar]').forEach(button => {
      button.classList.toggle('active', button.dataset.avatar === selectedAvatar);
      button.setAttribute('aria-pressed', String(button.dataset.avatar === selectedAvatar));
    });
  }
  function openCustomize() {
    applyCustomization();
    $('customizeModal').classList.remove('hidden');
  }
  function closeCustomize() { $('customizeModal').classList.add('hidden'); }
  function avatarFor(player, index=0) {
    if (player.id === myId) return selectedAvatar;
    if (player.isAI) return ['person3','person5','person7'][Math.max(0,index) % 3];
    return ['person2','person4','person6','person8'][Math.max(0,index) % 4];
  }
  function avatarMarkup(player, index=0) {
    const portrait = avatarFor(player,index);
    return `<div class="avatar ${player.isAI?'bot-avatar':''}" aria-label="Avatar de jugador"><img src="/assets/avatars/${portrait}.webp" alt="" loading="lazy"></div>`;
  }
  function showScreen(id) {
    screens.forEach(name => $(name).classList.toggle('hidden', name !== id));
  }
  function escapeHtml(value) {
    return String(value ?? '').replace(/[&<>"']/g, ch => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[ch]));
  }
  function toast(message) {
    const node = $('toast'); node.textContent = message; node.classList.add('show');
    clearTimeout(toastTimer); toastTimer = setTimeout(() => node.classList.remove('show'), 2600);
  }
  function setNotice(message, kind='info') {
    const node = $('gameNotice');
    node.textContent = message; node.classList.remove('hidden','error');
    if (kind === 'error') node.classList.add('error');
    lastNotice = message;
    setTimeout(() => { if (lastNotice === message) node.classList.add('hidden'); }, 5000);
  }
  function colorName(color) { return ({red:'rojo',blue:'azul',black:'negro',orange:'naranja'})[color] || ''; }
  function tileLabel(tile) { return tile.joker ? '★' : tile.n; }
  function tileClass(tile) { return tile.joker ? 'joker' : tile.color; }
  // Las escaleras se presentan siempre de menor a mayor, también cuando incluyen comodín.
  function sortRunTiles(tiles) {
    if (!Array.isArray(tiles) || tiles.length < 2) return tiles;
    const resolved = tiles.map(tile => tile.joker ? tile.as : tile);
    if (resolved.some(tile => !tile || !tile.color || !Number.isInteger(tile.n))) return tiles;
    if (resolved.every(tile => tile.color === resolved[0].color) && new Set(resolved.map(tile => tile.n)).size === tiles.length) {
      tiles.sort((a,b) => (a.joker ? a.as.n : a.n) - (b.joker ? b.as.n : b.n));
    }
    return tiles;
  }
  function tileHtml(tile, zone) {
    const active = selected.has(tile.id) ? ' selected' : '';
    const assignment = tile.joker && tile.as ? `<span class="tiny-as">${tile.as.n}${tile.as.color[0].toUpperCase()}</span>` : '';
    return `<button class="tile ${tileClass(tile)}${active}" data-tile="${escapeHtml(tile.id)}" data-zone="${zone}" aria-label="${tile.joker?'Comodín':`${tile.n} ${colorName(tile.color)}`}" aria-pressed="${selected.has(tile.id)}" title="${tile.joker?'Comodín':`${tile.n} ${colorName(tile.color)}`}" ${(!state?.isYourTurn || state?.finished)?'disabled':''}>${tileLabel(tile)}${assignment}</button>`;
  }
  function resetDraft() {
    if (!state) return;
    draftGroups = (state.table || []).map((group, i) => ({ gid: `server-${i}-${group.map(t=>t.id).join('-')}`, tiles: sortRunTiles(JSON.parse(JSON.stringify(group))) }));
    draftHand = JSON.parse(JSON.stringify(state.hand || []));
    selected.clear(); targetGroup = null;
    originalHandIds = new Set((state.hand || []).map(t => t.id));
    originalTableIds = new Set((state.table || []).flat().map(t => t.id));
    renderGame();
  }
  function selectedTiles() {
    const found = [];
    for (const tile of draftHand) if (selected.has(tile.id)) found.push(tile);
    for (const group of draftGroups) for (const tile of group.tiles) if (selected.has(tile.id)) found.push(tile);
    return found;
  }
  function removeSelectedFromSources() {
    draftHand = draftHand.filter(tile => !selected.has(tile.id));
    draftGroups = draftGroups.map(group => ({...group, tiles: sortRunTiles(group.tiles.filter(tile => !selected.has(tile.id)))})).filter(group => group.tiles.length > 0);
  }
  function makeGroup() {
    if (!canEdit() || selected.size < 1) return;
    const tiles = selectedTiles();
    if (!tiles.length) return;
    removeSelectedFromSources();
    draftGroups.push({ gid: `local-${Math.random().toString(36).slice(2)}`, tiles: sortRunTiles(tiles.map(t => JSON.parse(JSON.stringify(t)))) });
    selected.clear(); targetGroup = null; renderGame();
  }
  function addToGroup() {
    if (!canEdit() || !targetGroup || selected.size < 1) return;
    const target = draftGroups.find(g => g.gid === targetGroup);
    if (!target) return toast('Selecciona primero el grupo al que quieres añadir fichas.');
    const tiles = selectedTiles();
    if (!tiles.length || tiles.some(t => target.tiles.some(x => x.id === t.id))) return;
    const targetId = target.gid;
    removeSelectedFromSources();
    const freshTarget = draftGroups.find(g => g.gid === targetId);
    if (!freshTarget) {
      draftGroups.push({gid:`local-${Math.random().toString(36).slice(2)}`,tiles:sortRunTiles(tiles)});
    } else {
      freshTarget.tiles.push(...tiles.map(t => JSON.parse(JSON.stringify(t))));
      sortRunTiles(freshTarget.tiles);
    }
    selected.clear(); renderGame();
  }
  function returnToRack() {
    if (!canEdit() || selected.size < 1) return;
    const movable = [];
    for (const group of draftGroups) for (const tile of group.tiles) {
      if (selected.has(tile.id) && (originalHandIds.has(tile.id) || (tile.joker && originalTableIds.has(tile.id)))) movable.push(tile);
    }
    if (!movable.length) return toast('Solo puedes devolver al atril fichas que eran tuyas al comenzar el turno.');
    const ids = new Set(movable.map(t=>t.id));
    draftGroups = draftGroups.map(g=>({...g,tiles:g.tiles.filter(t=>!ids.has(t.id))})).filter(g=>g.tiles.length);
    draftHand.push(...movable.map(t=>{const copy=JSON.parse(JSON.stringify(t)); if(copy.joker) delete copy.as; return copy;}));
    movable.forEach(t=>selected.delete(t.id));
    targetGroup = null; renderGame();
  }
  function canEdit() { return !!(state && state.isYourTurn && !state.finished); }
  function renderLobby() {
    if (!state) return;
    $('roomCodeDisplay').textContent = roomCode || state.code;
    $('playerCount').textContent = `${state.players.length} / 4`;
    $('lobbyPlayers').innerHTML = state.players.map((p,i)=>`<div class="lobby-player">${avatarMarkup(p,i)}<div><div class="player-name">${escapeHtml(p.name)} ${p.id===state.host?'<span class="host-tag">ANFITRIÓN</span>':''}</div><div class="player-status">${p.isAI?'● Inteligencia artificial':(p.connected?'● Conectado':'○ Desconectado')}${p.id===myId?' · Tú':''}</div></div></div>`).join('') + Array.from({length:Math.max(0,4-state.players.length)},()=>`<div class="lobby-player empty-seat"><div class="avatar">＋</div><div><div class="player-name">Esperando jugador</div><div class="player-status">Comparte el código para invitar</div></div></div>`).join('');
    const host = state.host === myId;
    $('startButton').disabled = !host || state.players.length < 2 || state.players.some(p=>!p.isAI && !p.connected);
    $('startButton').textContent = !host ? 'Esperando al anfitrión' : state.players.length < 2 ? 'Esperando jugadores' : 'Comenzar partida ↗';
    $('lobbyStatus').textContent = state.players.length < 2 ? 'Se necesitan al menos 2 jugadores.' : (host ? 'Todos listos. ¡Que comience la partida!' : 'El anfitrión iniciará cuando estén listos.');
  }
  function renderOpponents() {
    const others = (state.players || []).filter(p => p.id !== myId);
    $('opponents').style.gridTemplateColumns = `repeat(${Math.max(1,Math.min(3,others.length))},minmax(0,1fr))`;
    $('opponents').innerHTML = others.map((p,index)=>`<div class="opponent ${p.id===state.turnPlayer?'active':''}">${avatarMarkup(p,index)}<div class="opponent-info"><div class="opponent-name">${escapeHtml(p.name)} ${p.id===state.turnPlayer?'◈':''}</div><div class="opponent-meta">${p.isAI?'Rival IA':(p.connected?'Conectado':'Desconectado')} · ${p.handCount} fichas</div></div><div class="opponent-points">${p.score>=0?'+':''}${p.score}</div></div>`).join('');
  }
  function renderTable() {
    const groups = draftGroups;
    groups.forEach(group => sortRunTiles(group.tiles));
    $('tableCount').textContent = `${groups.length} ${groups.length===1?'combinación':'combinaciones'}`;
    if (!groups.length) {
      $('tableArea').innerHTML = `<div class="empty-table"><div class="empty-glyph">✧</div><strong>La mesa espera la primera jugada</strong><span>Las combinaciones válidas aparecerán aquí.</span></div>`;
      return;
    }
    $('tableArea').innerHTML = groups.map((g,index)=>`<div class="tile-group ${targetGroup===g.gid?'target':''}" data-group="${escapeHtml(g.gid)}"><button class="group-head ${targetGroup===g.gid?'active':''}" data-target="${escapeHtml(g.gid)}">GRUPO ${index+1}${targetGroup===g.gid?' · DESTINO':''}</button>${g.tiles.map(tile=>tileHtml(tile,'table')).join('')}</div>`).join('');
  }
  function renderRack() {
    $('rack').classList.toggle('inactive',!canEdit());
    // Mantener exactamente el orden manual del atril: no ordenar por color ni número.
    $('rack').innerHTML = draftHand.map(tile=>tileHtml(tile,'hand')).join('');
    $('handCount').textContent = draftHand.length;
    $('selectionCount').textContent = `${selected.size} ${selected.size===1?'ficha seleccionada':'fichas seleccionadas'}`;
    $('targetHint').textContent = targetGroup ? 'Destino seleccionado: toca “Añadir al grupo”.' : 'Toca fichas y crea una combinación.';
    $('makeGroupButton').disabled = !canEdit() || selected.size < 1;
    $('addGroupButton').disabled = !canEdit() || selected.size < 1 || !targetGroup;
    $('returnButton').disabled = !canEdit() || ![...selected].some(id=>(originalHandIds.has(id) || (originalTableIds.has(id) && [...draftGroups].some(g=>g.tiles.some(t=>t.id===id && t.joker)))) && !draftHand.some(t=>t.id===id));
    $('undoButton').disabled = !canEdit();
    $('drawButton').disabled = !canEdit();
    $('playButton').disabled = !canEdit();
  }
  function renderGame() {
    if (!state) return;
    $('gameRoomCode').textContent = roomCode || state.code;
    $('drawCount').textContent = state.drawCount;
    $('turnText').textContent = state.finished ? 'Ronda terminada' : state.isYourTurn ? 'Es tu turno' : `Turno de ${state.players.find(p=>p.id===state.turnPlayer)?.name || 'otro jugador'}`;
    $('turnChip').style.borderColor = state.isYourTurn ? 'rgba(216,182,110,.45)' : '';
    $('openingBadge').textContent = state.opened ? '✓ Apertura completada' : 'Aún no has abierto';
    $('turnHint').textContent = state.isYourTurn ? 'Puedes mover tus fichas' : 'Esperando tu turno';
    $('myPlayerTitle').innerHTML = `<img id="myAvatar" class="own-avatar" src="/assets/avatars/${selectedAvatar}.webp" alt="Avatar seleccionado"> ${escapeHtml(state.players.find(p=>p.id===myId)?.name || 'Tus fichas')} <span id="handCount" class="hand-count">${draftHand.length}</span>`;
    renderOpponents(); renderTable(); renderRack();
    $('drawButton').textContent = `Robar ficha ＋ (${state.drawCount})`;
    $('drawButton').disabled = !canEdit();
    $('drawButton').textContent = state.drawCount > 0 ? `Robar ficha ＋ (${state.drawCount})` : 'Montón vacío · pasar turno';
    $('playButton').disabled = !canEdit();
    $('makeGroupButton').disabled = !canEdit() || selected.size===0;
    $('addGroupButton').disabled = !canEdit() || selected.size===0 || !targetGroup;
    $('returnButton').disabled = !canEdit() || ![...selected].some(id=>(originalHandIds.has(id) || (originalTableIds.has(id) && [...draftGroups].some(g=>g.tiles.some(t=>t.id===id && t.joker)))) && !draftHand.some(t=>t.id===id));
    $('undoButton').disabled = !canEdit();
    if (state.finished && state.result) {
      const scores = state.result.scores.map(s=>`<span class="result-person">${escapeHtml(s.name)} · atril ${s.handPoints}<b>${s.totalScore>=0?'+':''}${s.totalScore} pts</b></span>`).join('');
      $('resultPanel').innerHTML = `<h2>🏆 ${escapeHtml(state.result.winnerName)} gana la ronda</h2><p>${escapeHtml(state.result.reason)}</p><div class="result-table">${scores}</div>${state.host===myId?'<button id="newRoundButton" class="primary-button">Jugar otra ronda ↗</button>':''}`;
      $('resultPanel').classList.remove('hidden');
      $('newRoundButton')?.addEventListener('click',()=>socket.emit('newRound'));
    } else $('resultPanel').classList.add('hidden');
    $('playButton').disabled = !canEdit();
    if (!state.isYourTurn) $('selectionCount').textContent = 'Turno de otro jugador';
  }
  function onTileClick(event) {
    const tile = event.currentTarget;
    if (!canEdit()) return;
    const id = tile.dataset.tile;
    if (selected.has(id)) selected.delete(id); else selected.add(id);
    renderTable(); renderRack();
    bindTileEvents();
  }
  function bindTileEvents() {
    // Las fichas del atril se seleccionan en pointerup para que un toque móvil
    // no dependa del click sintético del navegador. Las de la mesa usan click.
    document.querySelectorAll('.tile[data-zone="table"]').forEach(el=>el.addEventListener('click',onTileClick));
    document.querySelectorAll('[data-target]').forEach(el=>el.addEventListener('click',()=>{
      if (!canEdit()) return;
      targetGroup = targetGroup===el.dataset.target ? null : el.dataset.target;
      renderTable(); bindTileEvents();
    }));
  }

  // Reordenar el atril arrastrando y soltando, compatible con mouse y pantallas táctiles.
  // Solo cambia la presentación local; no altera valores, combinaciones ni reglas.
  document.addEventListener('pointerdown', event => {
    const tile = event.target.closest('#rack .tile[data-zone="hand"]');
    if (!tile || !canEdit() || event.button > 0) return;
    rackDrag = { id: tile.dataset.tile, pointerId: event.pointerId, startX: event.clientX,
      startY: event.clientY, moved: false };
    // Captura el puntero para que el toque no se pierda si el dedo sale del borde de la ficha.
    try { tile.setPointerCapture(event.pointerId); } catch (_) {}
  });
  function showMoveIndicator(x, y, groupElement) {
    let indicator = $('moveIndicator');
    if (!indicator) {
      indicator = document.createElement('div');
      indicator.id = 'moveIndicator';
      indicator.className = 'move-indicator';
      indicator.setAttribute('aria-live','polite');
      document.body.appendChild(indicator);
    }
    document.querySelectorAll('.tile-group.drop-target').forEach(el=>el.classList.remove('drop-target'));
    if (groupElement) {
      groupElement.classList.add('drop-target');
      const title = groupElement.querySelector('.group-head')?.textContent?.trim() || 'Combinación';
      indicator.textContent = `＋ Soltar en ${title}`;
      indicator.classList.add('valid-target');
    } else {
      indicator.textContent = 'Mueve sobre una combinación';
      indicator.classList.remove('valid-target');
    }
    indicator.style.left = `${Math.min(window.innerWidth - 220, Math.max(8, x + 14))}px`;
    indicator.style.top = `${Math.min(window.innerHeight - 54, Math.max(8, y + 16))}px`;
    indicator.classList.add('visible');
  }
  function hideMoveIndicator() {
    $('moveIndicator')?.classList.remove('visible');
    document.querySelectorAll('.tile-group.drop-target').forEach(el=>el.classList.remove('drop-target'));
  }
  document.addEventListener('pointermove', event => {
    if (!rackDrag || event.pointerId !== rackDrag.pointerId) return;
    if (!rackDrag.moved && Math.hypot(event.clientX-rackDrag.startX,event.clientY-rackDrag.startY) > 8) {
      rackDrag.moved = true;
      document.querySelector(`#rack [data-tile="${CSS.escape(rackDrag.id)}"]`)?.classList.add('dragging');
    }
    if (rackDrag.moved) {
      event.preventDefault();
      const under = document.elementFromPoint(event.clientX,event.clientY)?.closest('.tile-group');
      rackDrag.targetGid = under?.dataset.group || null;
      showMoveIndicator(event.clientX,event.clientY,under);
    }
  }, {passive:false});
  document.addEventListener('pointerup', event => {
    if (!rackDrag || event.pointerId !== rackDrag.pointerId) return;
    const drag = rackDrag; rackDrag = null;
    const sourceIndex = draftHand.findIndex(t=>t.id===drag.id);
    const underElement = document.elementFromPoint(event.clientX,event.clientY);
    const targetElement = underElement?.closest('.tile-group');
    const targetGid = targetElement?.dataset.group || null;
    document.querySelectorAll('#rack .tile.dragging').forEach(el=>el.classList.remove('dragging'));
    hideMoveIndicator();
    if (!drag.moved) {
      event.preventDefault();
      const id = drag.id;
      if (selected.has(id)) selected.delete(id); else selected.add(id);
      renderTable(); renderRack(); bindTileEvents();
      return;
    }
    // Arrastrar desde el atril hasta una combinación coloca la ficha allí y deja
    // una marca clara del destino antes de confirmar la jugada.
    if (sourceIndex >= 0 && targetGid) {
      const target = draftGroups.find(group=>group.gid===targetGid);
      if (target) {
        const [moving] = draftHand.splice(sourceIndex,1);
        target.tiles.push(moving);
        sortRunTiles(target.tiles);
        selected.delete(drag.id);
        targetGroup = targetGid;
        renderGame(); bindTileEvents();
        setNotice('Ficha colocada en la combinación. Puedes deshacer o confirmar la jugada.');
        return;
      }
    }
    // Si el destino no es una combinación, se conserva el gesto de ordenar el atril.
    const underRack = underElement?.closest('#rack .tile[data-zone="hand"]');
    const targetIndex = underRack ? draftHand.findIndex(t=>t.id===underRack.dataset.tile) : -1;
    if (sourceIndex >= 0 && targetIndex >= 0 && sourceIndex !== targetIndex) {
      // Intercambio directo: la ficha arrastrada ocupa exactamente el índice
      // de la ficha destino y esta pasa a la posición original. No insertar.
      const targetTile = draftHand[targetIndex];
      draftHand[targetIndex] = draftHand[sourceIndex];
      draftHand[sourceIndex] = targetTile;
      selected.delete(drag.id);
      renderRack(); bindTileEvents();
    }
  });
  document.addEventListener('pointercancel',event=>{
    if (rackDrag && event.pointerId !== rackDrag.pointerId) return;
    rackDrag=null;document.querySelectorAll('#rack .tile.dragging').forEach(el=>el.classList.remove('dragging'));hideMoveIndicator();
  });

  let reconnectPending = false;
  socket.on('connect', () => {
    $('connectionLabel').textContent = 'Conectado';
    const savedCode = localStorage.getItem('rummikubCode') || sessionStorage.getItem('rummikubCode');
    const savedToken = localStorage.getItem('rummikubToken') || sessionStorage.getItem('rummikubToken');
    if (savedCode && savedToken && !reconnectPending) {
      reconnectPending = true;
      socket.emit('reconnectRoom',{code:savedCode,token:savedToken}, result => {
        reconnectPending = false;
        if (!result?.ok) { $('connectionLabel').textContent = 'Sin sesión'; }
      });
    }
  });
  socket.on('disconnect', () => { reconnectPending = false; $('connectionLabel').textContent = 'Reconectando…'; });
  socket.on('connect_error', () => { $('connectionLabel').textContent = 'Error de conexión'; });
  socket.on('joined', data => {
    roomCode = data.code; myId = data.you; token = data.token;
    sessionStorage.setItem('rummikubCode',roomCode); sessionStorage.setItem('rummikubToken',token);
    localStorage.setItem('rummikubCode',roomCode); localStorage.setItem('rummikubToken',token);
    toast(data.restored ? 'Sesión recuperada.' : `Te uniste a la sala ${roomCode}.`);
  });
  socket.on('gameState', incoming => {
    const previousStarted = state?.started;
    const previousFinished = state?.finished;
    state = incoming;
    roomCode = incoming.code; myId = incoming.you;
    if (incoming.started) {
      if (!previousStarted || previousFinished || !state.isYourTurn || !draftGroups.length && !draftHand.length) resetDraft();
      // Actualizar siempre después de una acción aceptada o un cambio de turno.
      if (incoming.isYourTurn && (incoming.turnNumber !== window.lastTurnNumber || window.lastTurnOwner !== incoming.turnPlayer)) resetDraft();
      window.lastTurnNumber = incoming.turnNumber; window.lastTurnOwner = incoming.turnPlayer;
      showScreen('gameScreen'); renderGame(); bindTileEvents();
    } else {
      showScreen('lobbyScreen'); renderLobby();
    }
  });
  socket.on('botMessage', data => {
    setNotice(`🤖 ${data.name} ${data.message}`);
  });
  socket.on('notice', data => {
    const message = typeof data === 'string' ? data : data.message;
    toast(message);
    if (data.kind === 'error' && state?.started) setNotice(message,'error');
  });

  function emitWithFeedback(eventName, payload, button, fallbackMessage) {
    if (!socket.connected) { toast('Conectando con el servidor… espera un momento e inténtalo de nuevo.'); return; }
    const oldText = button.textContent; button.disabled = true; button.dataset.busy = '1';
    const timeout = setTimeout(() => { if (button.dataset.busy === '1') { button.disabled = false; delete button.dataset.busy; button.textContent = oldText; toast(fallbackMessage); } }, 10000);
    socket.emit(eventName, payload, result => {
      clearTimeout(timeout); button.disabled = false; delete button.dataset.busy; button.textContent = oldText;
      if (!result?.ok) toast(result?.message || fallbackMessage);
    });
  }
  $('createButton').addEventListener('click',()=>{
    const name = $('playerName').value.trim() || 'Jugador';
    localStorage.setItem('rummikubName',name);
    emitWithFeedback('createRoom',{name},$('createButton'),'El servidor no confirmó la creación. Intenta nuevamente.');
  });
  $('soloButton').addEventListener('click',()=>{
    const name = $('playerName').value.trim() || 'Jugador';
    localStorage.setItem('rummikubName',name);
    emitWithFeedback('createSoloRoom',{name,opponents:Number($('aiCount').value)},$('soloButton'),'No se pudo iniciar la partida contra la IA.');
  });
  $('joinButton').addEventListener('click',()=>{
    const name = $('playerName').value.trim() || 'Jugador';
    const code = $('roomCode').value.trim().toUpperCase();
    if (code.length !== 5) return toast('Escribe el código de sala de 5 caracteres.');
    localStorage.setItem('rummikubName',name);
    emitWithFeedback('joinRoom',{name,code},$('joinButton'),'No se recibió confirmación de la sala. Revisa tu conexión e inténtalo otra vez.');
  });
  $('roomCode').addEventListener('input',e=>e.target.value=e.target.value.toUpperCase().replace(/[^A-Z0-9]/g,'').slice(0,5));
  $('playerName').value = localStorage.getItem('rummikubName') || '';
  $('startButton').addEventListener('click',()=>socket.emit('startGame'));
  $('copyCodeButton').addEventListener('click',async()=>{
    try { await navigator.clipboard.writeText(roomCode || state?.code); toast('Código copiado. ¡Compártelo con tus amigos!'); }
    catch { toast(`Código de la sala: ${roomCode || state?.code}`); }
  });
  $('leaveLobbyButton').addEventListener('click',()=>{socket.emit('leaveRoom');sessionStorage.removeItem('rummikubCode');sessionStorage.removeItem('rummikubToken');localStorage.removeItem('rummikubCode');localStorage.removeItem('rummikubToken');state=null;roomCode=null;showScreen('homeScreen');});
  $('leaveGameButton').addEventListener('click',()=>{
    if (!confirm('¿Quieres salir de la partida? Tu lugar quedará desconectado.')) return;
    socket.emit('leaveRoom');sessionStorage.removeItem('rummikubCode');sessionStorage.removeItem('rummikubToken');localStorage.removeItem('rummikubCode');localStorage.removeItem('rummikubToken');state=null;roomCode=null;showScreen('homeScreen');
  });
  $('makeGroupButton').addEventListener('click',makeGroup);
  $('addGroupButton').addEventListener('click',addToGroup);
  $('returnButton').addEventListener('click',returnToRack);
  $('undoButton').addEventListener('click',()=>{resetDraft();toast('Se restauró la mesa al inicio de tu turno.');});
  $('drawButton').addEventListener('click',()=>{
    if (!canEdit()) return;
    if (selected.size || draftGroups.some((g,i)=>JSON.stringify(g.tiles)!==JSON.stringify(state.table[i]))) {
      if (!confirm('Robar ficha descartará los cambios que hayas hecho en esta jugada. ¿Continuar?')) return;
    }
    resetDraft();
    socket.emit('drawTile'); selected.clear();
  });
  $('playButton').addEventListener('click',()=>{
    if (!canEdit()) return;
    const groups = draftGroups.map(g=>g.tiles.map(t=>t.joker ? ({id:t.id,as:t.as || null}) : ({id:t.id})));
    socket.emit('playTurn',{groups,handIds:draftHand.map(t=>t.id)});
  });
  $('customizeButton').addEventListener('click',openCustomize);
  $('customizeHomeButton').addEventListener('click',openCustomize);
  $('customizeGameButton').addEventListener('click',openCustomize);
  $('closeCustomize').addEventListener('click',closeCustomize);
  $('doneCustomize').addEventListener('click',closeCustomize);
  $('customizeModal').addEventListener('click',e=>{if(e.target===$('customizeModal'))closeCustomize();});
  document.querySelectorAll('[data-theme]').forEach(button=>button.addEventListener('click',()=>{
    const theme=button.dataset.theme;
    if (!tileThemes.includes(theme)) return;
    selectedTheme=theme;localStorage.setItem('rummikubTileTheme',theme);applyCustomization();
    toast(`Estilo de fichas: ${button.querySelector('b')?.textContent || theme}.`);
  }));
  document.querySelectorAll('[data-avatar]').forEach(button=>button.addEventListener('click',()=>{
    const avatar=button.dataset.avatar;
    if (!avatarOptions.includes(avatar)) return;
    selectedAvatar=avatar;localStorage.setItem('rummikubAvatar',avatar);applyCustomization();
    if (state?.started) {renderOpponents();renderGame();} else if (state) {renderLobby();}
    toast('Avatar actualizado.');
  }));
  applyCustomization();
  const openHelp = () => { $('helpModal').classList.remove('hidden'); $('closeHelp').focus(); };
  const closeHelp = () => $('helpModal').classList.add('hidden');
  $('helpButton').addEventListener('click',openHelp);
  $('homeRulesButton').addEventListener('click',openHelp);
  $('closeHelp').addEventListener('click',closeHelp);
  $('helpModal').addEventListener('click',e=>{if(e.target===$('helpModal'))closeHelp();});
  document.addEventListener('keydown',e=>{if(e.key==='Escape' && !$('helpModal').classList.contains('hidden'))closeHelp();});
})();
