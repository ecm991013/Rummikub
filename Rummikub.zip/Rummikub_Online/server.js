const express = require('express');
const http = require('http');
const crypto = require('crypto');
const { Server } = require('socket.io');

const app = express();
const httpServer = http.createServer(app);
const io = new Server(httpServer);
const PORT = process.env.PORT || 3000;
const COLORS = ['red', 'blue', 'black', 'orange'];
const rooms = new Map();
const socketRooms = new Map();

app.use(express.static('public'));
app.get('/api/ping', (_req, res) => res.json({ ok: true, app: 'Rummikub Online' }));

const uid = () => crypto.randomUUID();
const clone = value => JSON.parse(JSON.stringify(value));
const shuffle = array => {
  for (let i = array.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [array[i], array[j]] = [array[j], array[i]];
  }
  return array;
};

function makeTiles() {
  const tiles = [];
  for (let copy = 0; copy < 2; copy++) {
    for (const color of COLORS) {
      for (let n = 1; n <= 13; n++) tiles.push({ id: uid(), color, n, joker: false });
    }
  }
  tiles.push({ id: uid(), joker: true }, { id: uid(), joker: true });
  return shuffle(tiles);
}

function exactGroup(group) {
  if (!Array.isArray(group) || group.length < 3 || group.length > 4) return false;
  if (group.some(t => t.joker && (!t.as || !COLORS.includes(t.as.color) || !Number.isInteger(t.as.n) || t.as.n < 1 || t.as.n > 13))) return false;
  const resolved = group.map(t => t.joker ? { color: t.as.color, n: t.as.n } : { color: t.color, n: t.n });
  const nums = resolved.map(t => t.n);
  const colors = resolved.map(t => t.color);
  const isSet = nums.every(n => n === nums[0]) && new Set(colors).size === colors.length;
  const sorted = [...resolved].sort((a, b) => a.n - b.n);
  const isRun = resolved.every(t => t.color === colors[0]) &&
    new Set(nums).size === nums.length &&
    sorted[sorted.length - 1].n - sorted[0].n === sorted.length - 1;
  return isSet || isRun;
}

// Asigna a los comodines la primera representación válida. Los comodines que
// ya están en mesa conservan su representación salvo que se hayan recuperado.
function assignGroup(group) {
  if (!Array.isArray(group) || group.length < 3 || group.length > 4) return null;
  const jokers = [];
  group.forEach((tile, index) => { if (tile.joker && !tile.as) jokers.push(index); });
  if (jokers.length === 0) return exactGroup(group) ? group : null;
  const result = clone(group);
  function search(depth) {
    if (depth === jokers.length) return exactGroup(result) ? clone(result) : null;
    const index = jokers[depth];
    for (const color of COLORS) {
      for (let n = 13; n >= 1; n--) {
        result[index].as = { color, n };
        const found = search(depth + 1);
        if (found) return found;
      }
    }
    delete result[index].as;
    return null;
  }
  return search(0);
}

function scoreHand(hand) {
  return hand.reduce((sum, tile) => sum + (tile.joker ? 30 : tile.n), 0);
}

function publicRoom(room) {
  return {
    code: room.code,
    host: room.host,
    started: room.started,
    finished: room.finished,
    turnPlayer: room.players[room.turnIndex]?.id || null,
    turnNumber: room.turnNumber,
    drawCount: room.deck.length,
    table: clone(room.table),
    players: room.players.map(player => ({
      id: player.id,
      name: player.name,
      connected: player.connected,
      isAI: !!player.isAI,
      handCount: player.hand.length,
      score: player.score || 0,
      opened: !!room.opened[player.id]
    })),
    result: room.result || null
  };
}

function sendStates(room) {
  const shared = publicRoom(room);
  for (const player of room.players) {
    if (!player.connected || player.isAI) continue;
    io.to(player.id).emit('gameState', {
      ...shared,
      you: player.id,
      hand: clone(player.hand),
      opened: !!room.opened[player.id],
      isYourTurn: room.started && !room.finished && room.players[room.turnIndex]?.id === player.id
    });
  }
}

function notice(socket, message, kind = 'info') {
  socket.emit('notice', { message, kind });
}

function createRoom(socket, name) {
  let code;
  do { code = Math.random().toString(36).slice(2, 7).toUpperCase(); } while (rooms.has(code));
  const player = {
    id: socket.id,
    token: uid(),
    name: String(name || 'Jugador').trim().slice(0, 18) || 'Jugador',
    hand: [], connected: true, score: 0
  };
  const room = {
    code, host: player.id, players: [player], started: false, finished: false,
    table: [], deck: [], turnIndex: 0, turnNumber: 1, opened: {}, result: null, emptyPasses: 0
  };
  rooms.set(code, room);
  socket.join(code);
  socketRooms.set(socket.id, code);
  socket.emit('joined', { code, token: player.token, you: player.id });
  sendStates(room);
}

function beginRound(room) {
  const tiles = makeTiles();
  room.deck = tiles;
  room.table = [];
  // Se determina quién empieza tomando una ficha: el número más alto gana.
  // Las fichas de desempate vuelven al montón y se mezclan antes del reparto.
  let contenders = room.players.map((_, index) => index);
  while (contenders.length > 1) {
    const draws = contenders.map(index => ({ index, tile: room.deck.pop() }));
    const highest = Math.max(...draws.map(draw => draw.tile.joker ? 0 : draw.tile.n));
    contenders = draws.filter(draw => (draw.tile.joker ? 0 : draw.tile.n) === highest).map(draw => draw.index);
    room.deck.push(...draws.map(draw => draw.tile));
    shuffle(room.deck);
  }
  room.players.forEach(player => { player.hand = room.deck.splice(0, 14); player.connected = true; });
  room.turnIndex = contenders[0] ?? 0;
  room.turnNumber = 1;
  room.emptyPasses = 0;
  room.opened = Object.fromEntries(room.players.map(player => [player.id, false]));
  room.started = true;
  room.finished = false;
  room.result = null;
}

function endRound(room, reason, forcedWinnerId = null) {
  const ranking = room.players.map(player => ({ player, points: scoreHand(player.hand) }));
  let winner = forcedWinnerId ? room.players.find(p => p.id === forcedWinnerId) : null;
  if (!winner) {
    ranking.sort((a, b) => a.points - b.points);
    winner = ranking[0]?.player || null;
  }
  if (winner) {
    // En una ronda normal el ganador no conserva fichas y recibe la suma
    // de los puntos rivales. Si se agota el montón, se puntúa por diferencia:
    // se resta a cada rival el valor que aún conserva el ganador.
    const winnerPoints = scoreHand(winner.hand);
    for (const player of room.players) {
      if (player.id === winner.id) continue;
      const loss = Math.max(0, scoreHand(player.hand) - winnerPoints);
      player.score -= loss;
      winner.score += loss;
    }
  }
  room.finished = true;
  room.result = {
    winnerId: winner?.id || null,
    winnerName: winner?.name || 'Sin ganador',
    reason,
    scores: room.players.map(player => ({ id: player.id, name: player.name, handPoints: scoreHand(player.hand), totalScore: player.score }))
  };
}

function advance(room) {
  room.turnIndex = (room.turnIndex + 1) % room.players.length;
  room.turnNumber += 1;
}

function findTileById(room, id) {
  for (const player of room.players) {
    const tile = player.hand.find(t => t.id === id);
    if (tile) return tile;
  }
  for (const group of room.table) {
    const tile = group.find(t => t.id === id);
    if (tile) return tile;
  }
  return null;
}

function validateAndApply(room, player, payload) {
  if (!Array.isArray(payload.groups) || !Array.isArray(payload.handIds)) return 'La jugada enviada no tiene un formato válido.';
  if (payload.groups.length > 40 || payload.groups.some(g => !Array.isArray(g) || g.length > 4)) return 'La mesa contiene demasiados grupos o fichas.';

  const beforeTableGroups = clone(room.table);
  const beforeTable = beforeTableGroups.flat();
  const beforeHand = clone(player.hand);
  const beforeTableIds = new Set(beforeTable.map(t => t.id));
  const beforeHandIds = new Set(beforeHand.map(t => t.id));
  const allAllowed = new Set([...beforeTableIds, ...beforeHandIds]);

  const proposedGroups = [];
  const flatProposed = [];
  for (const rawGroup of payload.groups) {
    if (!Array.isArray(rawGroup)) return 'Hay un grupo inválido.';
    const group = [];
    for (const raw of rawGroup) {
      if (!raw || typeof raw.id !== 'string' || !allAllowed.has(raw.id)) return 'Se intentó utilizar una ficha que no pertenece a esta jugada.';
      const base = findTileById(room, raw.id) || beforeHand.find(t => t.id === raw.id) || beforeTable.find(t => t.id === raw.id);
      if (!base) return 'No se encontró una ficha de la jugada.';
      const tile = clone(base);
      if (tile.joker) {
        if (raw.as && COLORS.includes(raw.as.color) && Number.isInteger(raw.as.n) && raw.as.n >= 1 && raw.as.n <= 13) tile.as = { color: raw.as.color, n: raw.as.n };
        else if (raw.as === null || !tile.as) delete tile.as;
      }
      group.push(tile);
      flatProposed.push(tile);
    }
    if (group.length) proposedGroups.push(group);
  }

  const recoverableJokers = new Set(beforeTable.filter(tile => tile.joker).map(tile => tile.id));
  const handIds = payload.handIds;
  if (handIds.some(id => typeof id !== 'string' || (!beforeHandIds.has(id) && !recoverableJokers.has(id)))) return 'Tu atril contiene una ficha que no te pertenece.';
  if (new Set(handIds).size !== handIds.length) return 'Hay fichas duplicadas en tu atril.';
  const proposedIds = flatProposed.map(t => t.id);
  if (new Set(proposedIds).size !== proposedIds.length) return 'No puedes usar una misma ficha dos veces.';
  const afterHandSet = new Set(handIds);
  const combined = new Set([...proposedIds, ...handIds]);
  if (combined.size !== allAllowed.size || [...allAllowed].some(id => !combined.has(id))) return 'No puedes retirar fichas de la mesa ni hacer desaparecer fichas de tu atril.';

  // Las fichas normales que ya estaban en mesa no pueden volver al atril.
  for (const tile of beforeTable) {
    if (!tile.joker && afterHandSet.has(tile.id)) return 'Solo puedes recuperar un comodín de la mesa, no una ficha normal.';
  }

  const ownPlayed = beforeHand.filter(tile => proposedIds.includes(tile.id));
  if (ownPlayed.length === 0) return 'Debes colocar al menos una ficha de tu atril en la mesa.';

  // En la primera apertura no se pueden tocar las combinaciones existentes.
  if (!room.opened[player.id]) {
    const oldGroupKeys = beforeTableGroups.map(g => g.map(t => t.id).sort().join('|')).sort();
    const retainedOldGroups = proposedGroups.filter(g => g.some(t => beforeTableIds.has(t.id)));
    const newGroupKeys = retainedOldGroups.map(g => g.map(t => t.id).sort().join('|')).sort();
    if (JSON.stringify(oldGroupKeys) !== JSON.stringify(newGroupKeys)) return 'Para tu primera apertura debes usar únicamente fichas de tu atril; no puedes modificar la mesa.';
    if (proposedGroups.some(g => g.some(t => beforeTableIds.has(t.id)) && g.some(t => beforeHandIds.has(t.id)))) return 'En tu apertura no puedes añadir fichas a combinaciones que ya estaban en la mesa.';
  }

  // Asignar comodines nuevos y validar todas las combinaciones finales.
  const normalizedGroups = [];
  for (const group of proposedGroups) {
    const normalized = assignGroup(group);
    if (!normalized) return 'Hay una combinación inválida. Un grupo debe ser una escalera del mismo color o un conjunto del mismo número y colores distintos.';
    normalizedGroups.push(normalized);
  }

  // Para recuperar un comodín, su combinación original debe conservarse
  // sustituyéndolo por la ficha exacta que representaba. El comodín recuperado
  // debe quedar empleado en otra combinación durante el mismo turno.
  const normalizedFlat = normalizedGroups.flat();
  for (const oldGroup of beforeTableGroups) {
    for (const oldTile of oldGroup) {
      if (!oldTile.joker || !oldTile.as) continue;
      const destinationGroup = normalizedGroups.find(group => group.some(tile => tile.id === oldTile.id));
      const oldRemainderIds = oldGroup.filter(tile => tile.id !== oldTile.id).map(tile => tile.id);
      const remainsWithOriginalGroup = destinationGroup && oldRemainderIds.every(id => destinationGroup.some(tile => tile.id === id));
      const currentJoker = normalizedFlat.find(tile => tile.id === oldTile.id);
      const sameMeaning = currentJoker?.as && currentJoker.as.color === oldTile.as.color && currentJoker.as.n === oldTile.as.n;
      if (remainsWithOriginalGroup && sameMeaning) continue;

      // Regla flexible: retirar el comodín no exige sustitución si las fichas
      // que quedan en su combinación original siguen formando por sí solas
      // un grupo o escalera válido. Esto aplica tanto si el comodín vuelve al
      // atril como si se reutiliza en otra combinación durante el turno.
      // Si la combinación original queda incompleta (4-comodín-6), sí se
      // exige la ficha exacta que representaba y mantenerla en ese grupo.
      const remainingTiles = oldGroup.filter(tile => tile.id !== oldTile.id);
      const remainderIsValid = !!assignGroup(remainingTiles);
      if (remainderIsValid) continue;

      const replacement = beforeHand.find(tile => !tile.joker && tile.color === oldTile.as.color && tile.n === oldTile.as.n && proposedIds.includes(tile.id));
      if (!replacement) return `Para recuperar ese comodín debes colocar la ficha ${oldTile.as.n} ${oldTile.as.color} que representa, porque al quitarlo la combinación deja de ser válida.`;
      const replacementGroup = normalizedGroups.find(group => group.some(tile => tile.id === replacement.id) && oldRemainderIds.every(id => group.some(tile => tile.id === id)));
      if (!replacementGroup) return 'La ficha que sustituye al comodín debe quedar en la combinación original.';
      if (!destinationGroup || destinationGroup === replacementGroup) return 'Debes utilizar el comodín recuperado en otra combinación durante ese mismo turno.';
    }
  }

  if (!room.opened[player.id]) {
    const openingPoints = ownPlayed.reduce((sum, tile) => {
      if (!tile.joker) return sum + tile.n;
      const placed = normalizedFlat.find(t => t.id === tile.id);
      return sum + (placed?.as?.n || 0);
    }, 0);
    if (openingPoints < 30) return `Tu primera apertura debe sumar al menos 30 puntos. Llevas ${openingPoints}.`;
    room.opened[player.id] = true;
  }

  room.table = normalizedGroups;
  room.emptyPasses = 0;
  const handById = new Map(beforeHand.map(tile => [tile.id, tile]));
  for (const tile of beforeTable) {
    if (tile.joker) {
      const recovered = clone(tile);
      delete recovered.as;
      handById.set(tile.id, recovered);
    }
  }
  player.hand = handIds.map(id => handById.get(id));
  if (player.hand.length === 0) {
    endRound(room, 'Un jugador se quedó sin fichas.', player.id);
  } else {
    advance(room);
  }
  return null;
}

// IA táctica: encuentra combinaciones legales, prioriza fichas de mayor valor
// y puede hacer varias bajadas en un turno. En la apertura combina varias
// ternas/cuartetos hasta alcanzar 30 puntos.
function combinations(items, size, start = 0, prefix = [], out = []) {
  if (prefix.length === size) { out.push(prefix.slice()); return out; }
  for (let i = start; i <= items.length - (size - prefix.length); i++) {
    prefix.push(items[i]); combinations(items, size, i + 1, prefix, out); prefix.pop();
  }
  return out;
}
function aiCandidates(hand) {
  const candidates = [];
  const seen = new Set();
  for (const size of [4, 3]) {
    for (const combo of combinations(hand, size)) {
      const normalized = assignGroup(combo);
      if (!normalized) continue;
      const key = normalized.map(tile => tile.id).sort().join('|');
      if (seen.has(key)) continue;
      seen.add(key);
      const value = normalized.reduce((sum, tile) => sum + (tile.joker ? (tile.as?.n || 0) : tile.n), 0);
      candidates.push({ tiles: normalized, value, size });
    }
  }
  return candidates.sort((a, b) => b.value - a.value || b.size - a.size);
}
function chooseDisjointCandidates(hand, minimumPoints = 0) {
  const candidates = aiCandidates(hand);
  if (minimumPoints) {
    // La apertura puede requerir sumar varias combinaciones pequeñas. Una
    // búsqueda acotada evita que una elección voraz bloquee una apertura legal.
    candidates.sort((a, b) => b.size - a.size || b.value - a.value);
    let explored = 0;
    function search(start, usedIds, chosen, points) {
      if (points >= minimumPoints) return chosen;
      if (chosen.length >= Math.floor(hand.length / 3) || explored > 20000) return null;
      for (let index = start; index < candidates.length; index++) {
        explored++;
        if (explored > 20000) break;
        const candidate = candidates[index];
        if (candidate.tiles.some(tile => usedIds.has(tile.id))) continue;
        const nextUsed = new Set(usedIds);
        candidate.tiles.forEach(tile => nextUsed.add(tile.id));
        const result = search(index + 1, nextUsed, [...chosen, candidate.tiles], points + candidate.value);
        if (result) return result;
      }
      return null;
    }
    const solution = search(0, new Set(), [], 0);
    if (solution) {
      const used = new Set(solution.flat().map(tile => tile.id));
      const points = solution.flat().reduce((sum, tile) => sum + (tile.joker ? (tile.as?.n || 0) : tile.n), 0);
      return { groups: solution, used, points };
    }
  }

  const used = new Set();
  const groups = [];
  let points = 0;
  for (const candidate of candidates) {
    if (candidate.tiles.some(tile => used.has(tile.id))) continue;
    groups.push(candidate.tiles);
    candidate.tiles.forEach(tile => used.add(tile.id));
    points += candidate.value;
    if (minimumPoints && points >= minimumPoints) break;
  }
  return { groups, used, points };
}
function aiChooseMove(room, bot) {
  const hand = bot.hand;
  const opened = !!room.opened[bot.id];
  const baseGroups = clone(room.table);

  if (!opened) {
    const opening = chooseDisjointCandidates(hand, 30);
    if (opening.points < 30) return null;
    return {
      groups: [...baseGroups, ...opening.groups].map(group => group.map(tile => tile.joker ? ({ id: tile.id, as: tile.as || null }) : ({ id: tile.id }))),
      handIds: hand.filter(tile => !opening.used.has(tile.id)).map(tile => tile.id)
    };
  }

  // Primero intenta extender escaleras/grupos ya abiertos. Prueba las fichas
  // de mayor valor antes para reducir el riesgo de quedarse con puntos altos.
  const workingGroups = clone(baseGroups);
  const used = new Set();
  const handByValue = [...hand].sort((a, b) => (b.joker ? 30 : b.n) - (a.joker ? 30 : a.n));
  for (const tile of handByValue) {
    let placed = false;
    for (let gi = 0; gi < workingGroups.length; gi++) {
      if (workingGroups[gi].length >= 4) continue;
      const trial = [...workingGroups[gi], clone(tile)];
      const normalized = assignGroup(trial);
      if (!normalized) continue;
      workingGroups[gi] = normalized;
      used.add(tile.id);
      placed = true;
      break;
    }
    if (placed) continue;
  }

  const remaining = hand.filter(tile => !used.has(tile.id));
  const additional = chooseDisjointCandidates(remaining, 0);
  additional.used.forEach(id => used.add(id));
  const allGroups = [...workingGroups, ...additional.groups];
  if (used.size === 0) return null;

  return {
    groups: allGroups.map(group => group.map(tile => tile.joker ? ({ id: tile.id, as: tile.as || null }) : ({ id: tile.id }))),
    handIds: hand.filter(tile => !used.has(tile.id)).map(tile => tile.id)
  };
}

function scheduleAiTurn(room) {
  if (!room || room.finished || !room.started || room.aiTimer) return;
  const current = room.players[room.turnIndex];
  if (!current?.isAI) return;
  room.aiTimer = setTimeout(() => {
    room.aiTimer = null;
    if (room.finished || !room.started || room.players[room.turnIndex]?.id !== current.id) return;
    const move = aiChooseMove(room, current);
    if (move) {
      const problem = validateAndApply(room, current, move);
      if (!problem) io.to(room.code).emit('botMessage', { name: current.name, message: 'ha colocado fichas en la mesa.' });
      else {
        // Si una combinación no supera la validación del servidor, roba en vez
        // de bloquear la partida.
        if (room.deck.length) {
          current.hand.push(room.deck.pop());
          advance(room);
        } else {
          room.emptyPasses = (room.emptyPasses || 0) + 1;
          if (room.emptyPasses >= room.players.length) endRound(room, 'Todos pasaron sin poder jugar y el montón está vacío. Gana quien tenga menos puntos en su atril.');
          else advance(room);
        }
        io.to(room.code).emit('botMessage', { name: current.name, message: 'ha pasado su turno.' });
      }
    } else if (room.deck.length) {
      current.hand.push(room.deck.pop());
      advance(room);
      io.to(room.code).emit('botMessage', { name: current.name, message: 'ha robado una ficha.' });
    } else {
      room.emptyPasses = (room.emptyPasses || 0) + 1;
      if (room.emptyPasses >= room.players.length) endRound(room, 'Todos pasaron sin poder jugar y el montón está vacío. Gana quien tenga menos puntos en su atril.');
      else advance(room);
      io.to(room.code).emit('botMessage', { name: current.name, message: 'no pudo jugar y pasó.' });
    }
    sendStates(room);
    scheduleAiTurn(room);
  }, 1100 + Math.floor(Math.random()*900));
}

io.on('connection', socket => {
  socket.on('createRoom', ({ name } = {}) => createRoom(socket, name));

  socket.on('createSoloRoom', ({ name, opponents } = {}) => {
    createRoom(socket, name);
    const code = socketRooms.get(socket.id);
    const room = rooms.get(code);
    const count = Math.max(1, Math.min(3, Number(opponents) || 1));
    const levels = ['IA 1', 'IA 2', 'IA 3'];
    for (let i = 0; i < count; i++) room.players.push({
      id: `ai-${uid()}`, token: uid(), name: levels[i], hand: [], connected: true, score: 0, isAI: true
    });
    sendStates(room);
  });

  socket.on('joinRoom', ({ code, name } = {}) => {
    const room = rooms.get(String(code || '').trim().toUpperCase());
    if (!room) return notice(socket, 'No existe una sala con ese código.', 'error');
    if (room.started) return notice(socket, 'La partida ya comenzó. No se admiten más jugadores.', 'error');
    if (room.players.length >= 4) return notice(socket, 'La sala ya tiene 4 jugadores.', 'error');
    const player = {
      id: socket.id, token: uid(), name: String(name || 'Jugador').trim().slice(0, 18) || 'Jugador',
      hand: [], connected: true, score: 0
    };
    room.players.push(player);
    socket.join(room.code);
    socketRooms.set(socket.id, room.code);
    socket.emit('joined', { code: room.code, token: player.token, you: player.id });
    sendStates(room);
  });

  socket.on('reconnectRoom', ({ code, token } = {}) => {
    const room = rooms.get(String(code || '').trim().toUpperCase());
    const player = room?.players.find(p => p.token === token);
    if (!room || !player) return notice(socket, 'No se pudo recuperar esa sesión. Crea o únete a una sala.', 'error');
    const oldId = player.id;
    if (oldId !== socket.id) socketRooms.delete(oldId);
    player.id = socket.id;
    player.connected = true;
    if (room.host === oldId) room.host = socket.id;
    if (room.opened[oldId] !== undefined) {
      room.opened[socket.id] = room.opened[oldId];
      delete room.opened[oldId];
    }
    socket.join(room.code);
    socketRooms.set(socket.id, room.code);
    socket.emit('joined', { code: room.code, token: player.token, you: player.id, restored: true });
    sendStates(room);
  });

  socket.on('startGame', () => {
    const code = socketRooms.get(socket.id);
    const room = rooms.get(code);
    if (!room || room.host !== socket.id) return notice(socket, 'Solo quien creó la sala puede iniciar la partida.', 'error');
    if (room.started && !room.finished) return notice(socket, 'La partida ya está en curso.', 'error');
    if (room.players.length < 2) return notice(socket, 'Necesitas al menos 2 jugadores para comenzar.', 'error');
    if (room.players.length > 4) return notice(socket, 'El máximo es de 4 jugadores.', 'error');
    if (room.players.some(p => !p.isAI && !p.connected)) return notice(socket, 'Espera a que todos los jugadores estén conectados.', 'error');
    beginRound(room);
    sendStates(room);
    scheduleAiTurn(room);
  });

  socket.on('playTurn', payload => {
    const room = rooms.get(socketRooms.get(socket.id));
    if (!room || !room.started || room.finished) return notice(socket, 'No hay una partida activa.', 'error');
    const player = room.players.find(p => p.id === socket.id);
    if (!player || room.players[room.turnIndex]?.id !== socket.id) return notice(socket, 'No es tu turno.', 'error');
    const problem = validateAndApply(room, player, payload || {});
    if (problem) return notice(socket, problem, 'error');
    sendStates(room);
    scheduleAiTurn(room);
  });

  socket.on('drawTile', () => {
    const room = rooms.get(socketRooms.get(socket.id));
    if (!room || !room.started || room.finished) return notice(socket, 'No hay una partida activa.', 'error');
    const player = room.players.find(p => p.id === socket.id);
    if (!player || room.players[room.turnIndex]?.id !== socket.id) return notice(socket, 'No es tu turno.', 'error');
    if (room.deck.length === 0) {
      room.emptyPasses = (room.emptyPasses || 0) + 1;
      if (room.emptyPasses >= room.players.length) {
        endRound(room, 'Todos pasaron sin poder jugar y el montón está vacío. Gana quien tenga menos puntos en su atril.');
      } else {
        advance(room);
      }
      sendStates(room);
      scheduleAiTurn(room);
      return;
    }
    player.hand.push(room.deck.pop());
    advance(room);
    sendStates(room);
    scheduleAiTurn(room);
  });

  socket.on('newRound', () => {
    const room = rooms.get(socketRooms.get(socket.id));
    if (!room || !room.finished || room.host !== socket.id) return notice(socket, 'Solo el anfitrión puede iniciar otra ronda.', 'error');
    beginRound(room);
    sendStates(room);
    scheduleAiTurn(room);
  });

  socket.on('leaveRoom', () => {
    const code = socketRooms.get(socket.id);
    const room = rooms.get(code);
    if (!room) return;
    const player = room.players.find(p => p.id === socket.id);
    if (player && !room.started) room.players = room.players.filter(p => p.id !== socket.id);
    else if (player) player.connected = false;
    socket.leave(code);
    socketRooms.delete(socket.id);
    if (room.players.length === 0) rooms.delete(code);
    else {
      if (room.host === socket.id) {
        const replacement = room.players.find(p => p.connected);
        if (replacement) room.host = replacement.id;
      }
      sendStates(room);
    }
  });

  socket.on('disconnect', () => {
    const code = socketRooms.get(socket.id);
    const room = rooms.get(code);
    socketRooms.delete(socket.id);
    if (!room) return;
    const player = room.players.find(p => p.id === socket.id);
    if (player) player.connected = false;
    if (room.host === socket.id) {
      const replacement = room.players.find(p => p.connected);
      if (replacement) room.host = replacement.id;
    }
    sendStates(room);
  });
});

httpServer.listen(PORT, () => console.log(`Rummikub Online activo en el puerto ${PORT}`));
